#! /usr/bin/env python

import rospy
from nav_msgs.msg import Odometry
# from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point, Twist
import math

def euler_from_quaternion(x, y, z, w):
        """
        Convert a quaternion into euler angles (roll, pitch, yaw)
        roll is rotation around x in radians (counterclockwise)
        pitch is rotation around y in radians (counterclockwise)
        yaw is rotation around z in radians (counterclockwise)
        """
        t0 = +2.0 * (w * x + y * z)
        t1 = +1.0 - 2.0 * (x * x + y * y)
        roll_x = math.atan2(t0, t1)
     
        t2 = +2.0 * (w * y - z * x)
        t2 = +1.0 if t2 > +1.0 else t2
        t2 = -1.0 if t2 < -1.0 else t2
        pitch_y = math.asin(t2)
     
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw_z = math.atan2(t3, t4)
     
        return roll_x, pitch_y, yaw_z # in radians


# Update the path output from the A* code here

# This is path for [6,8] to [9,9]
# example_path = [(6, 8, 0, 0, 0, 0), (6.6875, 8.0, 0.0, 0.6269999999999998, 15, 15), (6.875, 8.0625, 67.75, 0.20900000000000002, 0, 10), (7.15625, 8.1875, -33.75, 0.3135, 15, 0), (7.5, 8.1875, 394.0, 0.209, 0, 10), (8.1875, 8.53125, 34.0, 0.6270000000000001, 15, 15), (8.875, 8.875, 34.0, 0.6270000000000001, 15, 15)]
 
# This is path for [8,5] to [7,7]
example_path = [(8, 5, 0, 0, 0, 0), (8.1875, 5.0625, 67.75, 0.20900000000000002, 0, 10), (8.1875, 5.375, 135.5, 0.20899999999999996, 0, 10), (7.84375, 5.71875, 135.5, 0.41800000000000015, 10, 10), (7.5, 6.0625, 135.5, 0.41800000000000015, 10, 10), (7.15625, 6.40625, 135.5, 0.41800000000000015, 10, 10), (7.15625, 6.6875, 67.75, 0.209, 10, 0), (7.03125, 6.96875, 169.25, 0.3134999999999999, 0, 15)]



x = 0
y = 0
theta = 0

r = 0.038
L = 0.354

rpm_path = []
for point in example_path:
	rpm_path.append((point[-2], point[-1]))

def newOdom(msg):
	global x
	global y
	global theta


	x = msg.pose.pose.position.x
	y = msg.pose.pose.position.y

	rot_q = msg.pose.pose.orientation
	_,_,theta = euler_from_quaternion(rot_q.x, rot_q.y, rot_q.z, rot_q.w)
	theta = theta * 180/3.14

rospy.init_node("closed_loop_controller")

sub = rospy.Subscriber("/odom", Odometry, newOdom)

pub = rospy.Publisher("/cmd_vel", Twist, queue_size = 1)

rate = rospy.Rate(10)

goal = Point()

target = Point()
target.x = example_path[-1][0] - 5
target.y = example_path[-1][1] - 5

rot = Twist()

rot_0 = Twist()
rot_0.linear.x = 0
rot_0.linear.y = 0
rot_0.linear.z = 0
rot_0.angular.x = 0
rot_0.angular.y = 0
rot_0.angular.z = 0

rot_z = Twist()
rot_z.linear.x = 0
rot_z.linear.y = 0
rot_z.linear.z = 0
rot_z.angular.x = 0
rot_z.angular.y = 0
rot_z.angular.z = 0.1

rot_nz = Twist()
rot_nz.linear.x = 0
rot_nz.linear.y = 0
rot_nz.linear.z = 0
rot_nz.angular.x = 0
rot_nz.angular.y = 0
rot_nz.angular.z = -0.1
node = 0
i = 0
print(len(rpm_path))
while not rospy.is_shutdown():

	linear_vel = 0.5*r * (rpm_path[i][0] + rpm_path[i][1])
	Thetan = (r / L) * (rpm_path[i][1] - rpm_path[i][0])
	rot.linear.x = linear_vel
	rot.angular.z = Thetan
	# print("Publishing RPM", node)
	pub.publish(rot)
	rate.sleep()
	# print("Entered Loop")
#	if i >= len(rpm_path):
#		pub.publish(rot_0)
#		print("Done")
#		break
	print("Target Distance", math.sqrt(math.pow(target.x - x, 2) + math.pow(target.y - y, 2)))

	if math.sqrt(math.pow(target.x - x, 2) + math.pow(target.y - y, 2)) < 1:
		pub.publish(rot_0)
		print("Done")
		break
	
	goal.x = example_path[node][0] - 5
	goal.y = example_path[node][1] - 5
	g_a = example_path[node][2]
	if example_path[node][2]> 360:
		g_a -=360
	goal_theta = g_a 

	dist = math.sqrt(math.pow(goal.x - x, 2) + math.pow(goal.y - y, 2))
	
	print("Node Distance", dist)
	if (0<=dist<=0.4 and rpm_path[i][1] != rpm_path[i][0] and -8<goal_theta - theta<8) or (0<=dist<=0.25 and rpm_path[i][1] == rpm_path[i][0]):
		while not -3<goal_theta - theta<3:
			if goal_theta - theta <0:
				pub.publish(rot_nz)
			elif goal_theta - theta >0:
				pub.publish(rot_z)
		print("theta", theta)
		print("Goal Theta", goal_theta)
		print(goal_theta - theta)

		pub.publish(rot_0)
		node +=1
		i += 1



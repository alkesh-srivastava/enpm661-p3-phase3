#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
import math
import time


# example_path = [(0, 0, 0, 0, 0), (0.6875, 0.0, 0.0, 0.0, 10, 15), (1.375, 0.0, 0.0, 0.0, 10, 15), (2.0625, 0.0, 0.0, 0.0, 10, 15), (2.75, 0.0, 0.0, 0.0, 10, 15), (3.4375, 0.0, 0.0, 0.0, 10, 15), (4.125, 0.0, 0.0, 0.0, 10, 15), (4.8125, 0.0, 0.0, 0.0, 10, 15), (5.0625, 0.1875, 78.875, 0.0, 0, 15), (5.0625, 0.875, 78.875, 0.0, 15, 15), (5.0625, 1.5625, 78.875, 0.0, 15, 15), (5.0625, 2.25, 78.875, 0.0, 15, 15), (5.0625, 2.9375, 78.875, 0.0, 15, 15), (5.28125, 3.15625, 0.0, 0.0, 15, 0), (5.96875, 3.15625, 0.0, 0.0, 10, 15), (6.125, 3.25, 78.875, 0.0, 0, 10), (6.25, 3.375, 0.0, 0.0, 10, 0), (6.40625, 3.46875, 78.875, 0.0, 0, 10), (6.40625, 4.15625, 78.875, 0.0, 15, 15), (6.40625, 4.84375, 78.875, 0.0, 15, 15), (6.40625, 5.53125, 78.875, 0.0, 15, 15), (6.40625, 6.21875, 78.875, 0.0, 15, 15), (6.40625, 6.90625, 78.875, 0.0, 15, 15), (6.40625, 7.59375, 78.875, 0.0, 15, 15), (6.625, 7.8125, 0.0, 0.0, 15, 0), (7.3125, 7.8125, 0.0, 0.0, 10, 15), (8.0, 7.8125, 0.0, 0.0, 10, 15), (8.6875, 7.8125, 0.0, 0.0, 10, 15), (8.9375, 8.0, 78.875, 0.0, 0, 15), (8.9375, 8.6875, 78.875, 0.0, 15, 15)]

example_path = [(6, 8, 0, 0, 0, 0), (6.6875, 8.0, 0.0, 0.6269999999999998, 15, 15), (6.875, 8.0625, 67.75, 0.20900000000000002, 0, 10), (7.15625, 8.1875, -33.75, 0.3135, 15, 0), (7.5, 8.1875, 394.0, 0.209, 0, 10), (8.1875, 8.53125, 34.0, 0.6270000000000001, 15, 15)]


#rpm_path = [(0,0), (0, 10), (15, 15), (0,10), (10,0)]
rpm_path = []
for point in example_path:
	rpm_path.append((point[-2], point[-1]))
# rpm_list = [(10,15), (10,15), (10,15),(10,15), (10,15), (10,15),(15,15)]
r = 0.038
L = 0.354

Thetan_time = 0

rospy.init_node("rpm_controller", anonymous = True)

pub = rospy.Publisher("/cmd_vel", Twist, queue_size = 1)

rate = rospy.Rate(10)

rot = Twist()

rot_0 = Twist()
rot_0.linear.x = 0
rot_0.linear.y = 0
rot_0.linear.z = 0
rot_0.angular.x = 0
rot_0.angular.y = 0
rot_0.angular.z = 0
# t = 0
i = 0
count = 1
print("Timer Begin")
measure_start = time.time()
measure1 = time.time()
measure2 = time.time()
while not rospy.is_shutdown():

    if measure2 - measure_start > len(rpm_path) - 1:
        print("Completed Through the list")
        pub.publish(rot_0)
        break
    linear_vel = 0.5*r * (rpm_path[i][0] + rpm_path[i][1])
    Thetan = (r / L) * (rpm_path[i][1] - rpm_path[i][0])
    rot.linear.x = linear_vel
    rot.angular.z = Thetan
    pub.publish(rot)
    measure2 = time.time()
    rate.sleep()

    if measure2 - measure1 >= 1:
        print("seconds PASSED IS", count)
        measure1 = measure2
        # measure2 = time.time()
        i += 1
        count += 1
    else:
        measure2 = time.time()
    #if i < len(rpm_path) - 1:
     #   print(i, "RPM completed")
      #  i +=1        
       # continue
#    else:
 #       print("Should Break")
  #      pub.publish(rot_0)
   #     # rospy.spin()
    #    break

        

